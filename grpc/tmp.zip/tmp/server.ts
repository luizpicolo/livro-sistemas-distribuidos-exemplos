import { loadPackageDefinition, Server, sendUnaryData, ServerUnaryCall, ServerCredentials } from '@grpc/grpc-js';
import { loadSync } from '@grpc/proto-loader';

type Task = { id: number; title: string };
type TaskList = { tasks: Task[] };
type Empty = {};

const tasksDefs = loadSync('./tasks.proto');
const tasksProto = loadPackageDefinition(tasksDefs) as any;

const tasks: Task[] = [
    { id: 1, title: 'Task 1' }
];

const grpcServer = new Server();

grpcServer.addService(tasksProto.TaskService.service, {
    FindAll: (_: ServerUnaryCall<Empty, TaskList>, callback: sendUnaryData<TaskList>) => {
        callback(null, { tasks });
    },
});

const serverAddress = '0.0.0.0:5050';
grpcServer.bindAsync(serverAddress, ServerCredentials.createInsecure(), () => {
    console.info(`Server started on ${serverAddress}`);
});