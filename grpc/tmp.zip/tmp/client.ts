import { credentials, loadPackageDefinition } from "@grpc/grpc-js";
import { loadSync } from "@grpc/proto-loader";

const tasksDefs = loadSync('./tasks.proto');
const tasksProto = loadPackageDefinition(tasksDefs) as any;

type Task = { id: number; title: string };
type TaskList = { tasks: Task[] };
// type Empty = {};

const clientGRPC = new tasksProto.TaskService(
    '127.0.0.1:5050',
    credentials.createInsecure()
);

clientGRPC.FindAll({}, (err: Error | null, response: TaskList) => {
  console.table(response.tasks);
});